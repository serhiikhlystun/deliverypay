$(document).ready(function () {

// base
	$('body').removeClass('no-js')
             .addClass('js');

	if ($) $ (function () {
		$ ('a').hover (
			function () {
				if (($ (this).attr ('href') != '') && ($ (this).attr ('href') != '#')) {
					$ ('a[href="' + $ (this).attr ('href') + '"]').addClass ('hover')
				}
			},
			function () {
				$ ('a').removeClass ('hover')
			}
		)
	});

  $('.tab-group').on('click', 'button:not(.active)', function () {
    $(this).addClass('active').siblings().removeClass('active')
      .closest('.tab-container').children('.tab-content').removeClass('active').eq($(this).index()).addClass('active');
  });

  $('.js-toggle').click(function(){
    $(this).toggleClass('active');
    $(this).closest('.js-toggle-container').find('.js-toggle-block').toggleClass('hidden');
    return false;
  });

  if ($(window).width() < 992) {
    $('.js-btn-main-menu').click(function(){
      $('.js-btn-main-menu').toggleClass('active');
      $('body').toggleClass('state-active-nav');
      $('.main-menu-nav').toggleClass('show');
      $('.nav-overlay').toggleClass('show');
      return false;
    });
  } else {
    $('.js-btn-main-menu').mouseover(function(){
      $('.header').removeClass('hide-me');
      return false;
    });
  }
  $(window).resize(function() {
    if ($(window).width() < 992) {
      $('.js-btn-main-menu').click(function(){
        $('.js-btn-main-menu').toggleClass('active');
        $('body').toggleClass('state-active-nav');
        $('.main-menu-nav').toggleClass('show');
        $('.nav-overlay').toggleClass('show');
        return false;
      });
    } else {
      $('.js-btn-main-menu').mouseover(function(){
        $('.header').removeClass('hide-me');
        return false;
      });
    }
  });

  

  $('.nav-overlay, .js-page-logo-top, .nav a[href^=#]').click(function(){
    $('.nav-overlay').removeClass('show');
    $('body').removeClass('state-active-nav');
    $('.main-menu-nav').removeClass('show');
    $('.js-btn-main-menu').removeClass('active');
    return false;
  });


  $('.autoplay').on('mouseenter', function(){
      $('.slider-preview').slick('slickPause');
  });
  $('.autoplay').on('mouseleave', function(){
      $('.slider-preview').slick('slickPlay');
  });


  $('.btn-annually-view').click(function(){
    $('.btn-annually-view').addClass('active');
    $('.btn-monthly-view').removeClass('active');
    $('.toggle-annually-content').removeClass('hidden');
    $('.toggle-monthly-content').addClass('hidden');
  });

  $('.btn-monthly-view').click(function(){
    $('.btn-monthly-view').addClass('active');
    $('.btn-annually-view').removeClass('active');
    $('.toggle-monthly-content').removeClass('hidden');
    $('.toggle-annually-content').addClass('hidden');
  });



// scroll function
    var $root = $('html, body');
    $('a:not(.js-link)').click(function() {
        $root.animate({
            scrollTop: $( $.attr(this, 'href') ).offset().top
        }, 200);
    });
    
    // widget preview
    setTimeout(function(){
      $('.preview-tool-window').removeClass('hide')
                               .addClass('auto-show');
      $('.wepster-button-hash').addClass('active');
    }, 2000);
  
    $('.wepster-button-hash').click(function() {
      $(this).toggleClass('active');
      $('.preview-tool-window').toggleClass('hide');
    });


    // widget preview

    class_menu = '.autonav';

    $(class_menu + " a").attr('id', function(i) {
        if(this.href.indexOf("#") != -1){
             str = $(this).attr('href');
             add_el = "id_" + str.substr(1, str.length)
             return add_el;
        }
    });

    var lastId,
        topMenu = $(class_menu),
        topMenuHeight = 300,
        menuItems = topMenu.find("a"),
        scrollItems = menuItems.map(function(){
            if(this.href.indexOf("#") != -1){
                var item = $($(this).attr("href"));
                if (item.length) { return item; }
            }
        });

    $(window).scroll(function(){
        var fromTop = $(this).scrollTop()+topMenuHeight;
        var cur = scrollItems.map(function(){
            if ($(this).offset().top < fromTop)
                return this;
        });
        cur = cur[cur.length-1];
        var id = cur && cur.length ? cur[0].id : "";

        $(class_menu+' a').removeClass('active');
        $('#id_'+id).addClass('active');

    });

// scroll function
    // nav hide
    $(window).on('scroll',function(){
      if ($(this).scrollTop() > 150) {
          $('.header').addClass('hide-me');
      } else {
          $('.header').removeClass('hide-me');
      }
    });

});
