$(document).ready(function () {

    $('.js-refresh-automation-animation').click(function(){
        $('body').removeClass('st2');
        $('.l-2_1 .circle').addClass('rotate-back');
        setTimeout(function(){
            $('body').addClass('st2');
            $('.l-2_1 .circle').removeClass('rotate-back');
        }, 400);
        return false;
    });


// scroll function
    var $root = $('html, body');
    $('a:not(.js-link)').click(function() {
        $root.animate({
            scrollTop: $( $.attr(this, 'href') ).offset().top
        }, 200);
        return false;
    });

    class_menu = '.autonav';

    $(class_menu + " a").attr('id', function(i) {
        if(this.href.indexOf("#") != -1){
             str = $(this).attr('href');
             add_el = "id_" + str.substr(1, str.length)
             return add_el;
        }
    });

    var lastId,
        topMenu = $(class_menu),
        topMenuHeight = 300,
        menuItems = topMenu.find("a"),
        scrollItems = menuItems.map(function(){
            if(this.href.indexOf("#") != -1){
                var item = $($(this).attr("href"));
                if (item.length) { return item; }
            }
        });

    $(window).scroll(function(){
        var fromTop = $(this).scrollTop()+topMenuHeight;
        var cur = scrollItems.map(function(){
            if ($(this).offset().top < fromTop)
                return this;
        });
        cur = cur[cur.length-1];
        var id = cur && cur.length ? cur[0].id : "";

        $(class_menu+' a').removeClass('active');
        $('#id_'+id).addClass('active');

        if(id == "what"
        || id == "attraction"
        || id == "automation"
        || id == "automation-middle"
        || id == "support"
        || id == "crm"
        || id == "sender"
        || id == "integration"
        ){
            $("body").addClass("stWhat");
        } else {
            $("body").removeClass("stWhat");
        }

        if(id == "attraction"
        || id == "automation-middle"
        || id == "automation"
        || id == "support"
        || id == "crm"
        || id == "sender"
        || id == "integration"
        ){
            $("body").addClass("st1");
        } else {
            $("body").removeClass("st1");
        }

        if(id == "automation"
        || id == "automation-middle"
        || id == "support"
        || id == "crm"
        || id == "sender"
        || id == "integration"
        ){
            $("body").addClass("st2");
        } else {
            $("body").removeClass("st2");
        }

        if(id == "automation-middle"
        || id == "support"
        || id == "crm"
        || id == "sender"
        || id == "integration"
        ){
            $("body").addClass("st2_1");
        } else {
            $("body").removeClass("st2_1");
        }

        if(id == "support"
        || id == "crm"
        || id == "sender"
        || id == "integration"
        ){
            $("body").addClass("st3");
        } else {
            $("body").removeClass("st3");
        }

        if(id == "crm"
        || id == "sender"
        || id == "integration"
        ){
            $("body").addClass("st3_1");
        } else {
            $("body").removeClass("st3_1");
        }

        if(id == "sender"
        || id == "integration"
        ){
            $("body").addClass("st4");
        } else {
            $("body").removeClass("st4");
        }

        if(id == "integration"
        ){
            $("body").addClass("st5");
        } else {
            $("body").removeClass("st5");
        }



        if(id == "why"){
            $("body").addClass("step-why");
        } else {
            $("body").removeClass("step-why");
        }

        if(id == "what"){
            $("body").addClass("step-what");
        } else {
            $("body").removeClass("step-what");
        }

        if(id == "attraction"){
            $("body").addClass("step-1");
        } else {
            $("body").removeClass("step-1");
        }

        if(id == "automation"){
            $("body").addClass("step-2");
        } else {
            $("body").removeClass("step-2");
        }

        if(id == "support"){
            $("body").addClass("step-3");
        } else {
            $("body").removeClass("step-3");
        }

        if(id == "crm"){
            $("body").addClass("step-3_1");
        } else {
            $("body").removeClass("step-3_1");
        }

        if(id == "sender"){
            $("body").addClass("step-4");
        } else {
            $("body").removeClass("step-4");
        }

    });
// scroll function

});
